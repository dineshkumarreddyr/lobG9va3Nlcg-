

		</div><!-- /. Container -->
		</div><!-- /# Mastehead -->  
	<!--slider ends-->
		
	<!--login starts-->
    <div class="container login-main">
      <div class="row">
        <div class="col-md-7 nopad-left">
            <img src="<?php echo base_url(); ?>assets/images/login.jpg" class="img-responsive">
        </div>
        <div class="col-md-5 login-card">
              <h1>Register</h1>
              <form method="post" action="">
                <input type="text" name="user" placeholder="Username">
                <input type="password" name="pass" placeholder="Password">
                <input type="password" name="pass" placeholder="Retype Password">
                <button type="button">Signup</button>
                <p>Already a Member? <a href="<?php echo base_url('login'); ?>">Signin Now</a></p>
              </form>
              <div class="or-box">
                    <span class="formor">OR</span>
              </div>
              <ul>
                <li><a href="#"><img src="<?php echo base_url(); ?>assets/images/sharefb.png" alt="facebook"></a></li>
                <li><a href="#"><img src="<?php echo base_url(); ?>assets/images/sharetw.png" alt="Twitter"></a></a></li>
                <li><a href="#"><img src="<?php echo base_url(); ?>assets/images/shareinst.png" alt="Instagram"></a></a></li>
              </ul>
          </div>
      </div>
    </div>
    <!--login ends-->	
