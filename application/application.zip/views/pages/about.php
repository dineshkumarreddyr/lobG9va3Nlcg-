		<div class="slideshow">
	    <div id="slideshow" class="carousel slide carousel-fade" data-ride="carousel" 
	    data-interval="3000">
	    <div class="carousel-inner">
	    <div class="item active">
	    <img class="img-responsive" src="<?php echo base_url();?>assets/images/about.jpg" alt="about Slide">
	    </div><!-- /. Item Active -->
	    </div><!-- /. Carousel-Inner -->
	    </div><!-- /# Slideshow .Carousel -->
	    </div><!-- /. Slideshow -->
		</div><!-- /. Container -->
		</div><!-- /# Mastehead -->  
	<!--slider ends-->

    <!--about starts-->
    <div class="container">
      <div class="about-main">
       <h2>Welcome to lookser</h2>
       <p>Lookser is an online fashion playground where the gap between fashion designers,consultants and shoppers is abridged. From discovering the new trends and chic styling , Lookser provides you a virtual canvas to showcase your complete outfit. With the best fashion desginers at your help, and almost every clothing item online to choose from , create the best mix-n-match for a perfect outing !</p>
       </div>
     </div>

      <div class="container-fluid abt-vision">
       <div class="container">
        <div class="row">
         <div class="col-md-7">
          <h2>Vision</h2>
          <p>At Lookser , we have one Vision — Fashion from all over the world at your footsteps. Our vision is to make the world a more stylish one. We are on a journey to simplifying everything, so that you can focus on your loved ones and things that matter the most. We are here to get to the solutions to your shopping hassles and bring the best of fashion trends,looks and products within a single window.</p>
          <h2>Mission</h2>
          <p>Our mission is to simplify diversified shopping into a single shopping window.As the world perceives the way fashion enhances the world, Lookser yearns to be the epitome of lead by example in the fashion domain, changing the way fashion will be experienced in coming future.</p>
         </div>
         </div>
       </div>
      </div>
      </div>
    </div>
    <!--about ends-->
